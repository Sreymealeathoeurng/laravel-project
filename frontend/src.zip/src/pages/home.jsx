import React from 'react';
import { useNavigate } from 'react-router-dom';

import '../assets/styling/home.scss';
import ScrollAnimation from "./ScrollAnimation";
import Footer from './Footer';
import RichTextEditor from './RichTextEditor';
import BookCategoriesSlider from './BookCategoriesSlider';

import pic from '../assets/images/1.png';
import pic6 from '../assets/images/img.png';
import pic3 from '../assets/images/intro3.png';
import pic5 from '../assets/images/novel.png';
import Logo from '../assets/images/logo.png';

const home = () => {
  const navigate = useNavigate();

  const menuItems = {
    BrowseBooks: [
      { name: 'Genres', path: '/genres' },
      { name: 'New Releases', path: '/new-releases' },
      { name: 'Recommended Reads', path: '/recommended' },
      { isDivider: true },
      { name: 'Book Clubs', path: '/book-clubs' }
    ],
    writingPub: [
      { name: 'Start Writing', path: '/start-writing' },
      { name: 'Public Guidelines', path: '/guidelines' },
      { name: 'Manage My Book', path: '/manage-books' }
    ],
    myBook: [
      { name: 'My Library', path: '/library' },
      { name: 'Edit Book', path: '/edit-book' },
      { isDivider: true },
      { name: 'Settings', path: '/settings' }
    ],
    community: [
      { name: 'Discussion Forums', path: '/forums' },
      { name: 'Book Recommendations', path: '/recommendations' },
      { isDivider: true },
      { name: 'Author Q&A Sessions', path: '/qa' }
    ]
  };

  const handleNavigation = (path) => {
    navigate(path);
  };

  const DropdownMenu = ({ items }) => (
    <ul className="dropdown-menu"  style={{color:' rgb(252, 252, 254)'}}>
      {items.map((item, index) =>
        item.isDivider ? (
          <li key={`divider-${index}`}>
            <hr className="dropdown-divider" />
          </li>
        ) : (
          <li key={item.path}>
            <a
              className="dropdown-item"
              href="#"
              onClick={(e) => {
                e.preventDefault();
                handleNavigation(item.path);
              }}
            >
              {item.name}
            </a>
          </li>
        )
      )}
    </ul>
  );

  return (
    <>
      <header>
        <nav className="menu">
          <div className="left-items">
            <div className="logo">
              <img src={Logo} alt="Company Logo" />
            </div>
            {Object.keys(menuItems).map((key) => (
              <div className="btn-group" key={key}>
                <button
                  type="button"
                  className="btn btn-danger dropdown-toggle"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </button>
                <DropdownMenu items={menuItems[key]} />
              </div>
            ))}
          </div>
          <div className="login-btn">
            <button aria-label="Login" onClick={() => handleNavigation('/login')}>
              <span className="box1">Login</span>
            </button>
            <button aria-label="Sign up" onClick={() => handleNavigation('/signup')}>
              <span className="box">Sign up</span>
            </button>
          </div>
        </nav>
      </header>

      <div className="home">
        <main>
          <section className='welcome-contact'>
            <img src={pic} alt="Welcome" />
            <div className="welcome-text">
              <h1>Free Online Book Writing <br />& Publishing</h1>
              <p>Unlock your creativity and share your stories with the world</p>
              <div className="start-btn">
                <button
                  className="contactButton"
                  aria-label="Join Now"
                  onClick={() => handleNavigation('/join')}
                >
                  Join Now
                  <div className="iconButton">
                    <svg height="24" width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 0h24v24H0z" fill="none" />
                      <path d="M16.172 11l-5.364-5.364 1.414-1.414L20 12l-7.778 7.778-1.414-1.414L16.172 13H4v-2z" fill="currentColor" />
                    </svg>
                  </div>
                </button>
              </div>
            </div>
          </section>

          <div className='intro-contact'>
            <h1 style={{ fontSize: '2em', color: '#262626', textShadow: '3px 3px 8px rgb(6, 48, 96)', position: 'relative', top: '-300px' }}>
              Quick access to all our features ensures a seamless experience as you embark on your writing journey.
            </h1>
            <div className="contact">
              <ScrollAnimation delay={0}>
                <article className='block1'>
                  <div className="images">
                    <img src={pic6} alt="Explore Categories" />
                  </div>
                  <div className="contact">
                    <h4>Explore Categories</h4>
                    <p>
                      Browse through a wide variety of book categories that cater to every genre. 
                      Whether you're a fan of fiction, non-fiction, mystery, romance, or fantasy, 
                      there's something for everyone.
                    </p>
                  </div>
                </article>
              </ScrollAnimation>

              <ScrollAnimation delay={300}>
                <article className='block2'>
                  <div className="contact">
                    <h4>Start Your Writing</h4>
                    <p>
                      Dive into the creative process with our intuitive writing dashboard. 
                      Whether you're drafting your first chapter or polishing a manuscript, 
                      we provide the tools you need to succeed.
                    </p>
                  </div>
                  <div className="images">
                    <img src={pic5} alt="Start Your Writing" />
                  </div>
                </article>
              </ScrollAnimation>

              <ScrollAnimation delay={600}>
                <article className='block3'>
                  <div className="images">
                    <img src={pic3} alt="Manage Publications" />
                  </div>
                  <div className="contact">
                    <h4>Manage Your Publications</h4>
                    <p>
                      Keep track of your authored books and manage your publications effortlessly. 
                      Our user-friendly interface allows you to create, update, edit, and publish 
                      your work with just a few clicks.
                    </p>
                  </div>
                </article>
              </ScrollAnimation>
            </div>
          </div>

          <footer className="bg-body-tertiary text-center">
            <Footer />
          </footer>
         <RichTextEditor/>
        </main>
      </div>
    </>
  );
};

export default home;