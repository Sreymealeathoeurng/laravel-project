import React from 'react';
import TextEditor from './textEditor';

const ChapterManager =()  =>{
     
    const handleSave = (title, content) => {
        const updatedChapters = chapters.map(chapter => 
            chapter.title === title ? { title, content } : chapter
        );
        setChapters(updatedChapters);
        console.log('Chapters:', updatedChapters);
    };

    const addChapter = () => {
        setChapters([...chapters, { title: `Chapter ${chapters.length + 1}`, content: '' }]);
    };

  return (
    <div>
         <h1>Book Writing App</h1>
            {chapters.map((chapter, index) => (
                <TextEditor
                    key={index}
                    chapterTitle={chapter.title}
                    initialContent={chapter.content}
                    onSave={handleSave}
                />
            ))}
            <button onClick={addChapter}>Add Chapter</button>
    </div>
  )
}

export default ChapterManager;
