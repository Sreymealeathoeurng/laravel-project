import React from 'react';
import { 
    FaBook, 
    FaEdit, 
    FaList, 
    FaUpload, 
    FaCog 
} from 'react-icons/fa';
import '../assets/styling/textEditor.scss';

const AuthorDashboard = ({ onSelect, activeItem }) => {
    const menuItems = [
        { name: "Book Details", icon: <FaBook />, component: "BookForm" },
        { name: "Chapter Manager", icon: <FaList />, component: "ChapterManager" },
        { name: "Publish Settings", icon: <FaUpload />, component: "PublishOptions" },
        { name: "Collaborators", icon: <FaEdit />, component: "Collaboration" },
        { name: "Advanced Settings", icon: <FaCog />, component: "Advanced" },
    ];

    const handleCreateBook = () => {
        // Logic to create a new book
        console.log("Create Book");
    };

    const handleEditBook = () => {
        // Logic to edit a selected book
        console.log("Edit Book");
    };

    return (
        <div className="dashboard">
            <header className="dashboard-header" >
                <details className="dropdown">
                    <summary className="avatar">
                        <img
                            src="https://gravatar.com/avatar/00000000000000000000000000000000?d=mp"
                            alt="User Avatar" />
                        <span className="username">John Carter</span>
                        <p className="role">Author</p>
                    </summary>
                    <ul>
                        <li>
                            <p>
                                <span className="block bold">Jane Doe</span>
                                <span className="block italic">jane@example.com</span>
                            </p>
                        </li>
                        <li>
                            <a href="#">
                                <span className="material-symbols-outlined"></span> Account
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span className="material-symbols-outlined"></span> Settings
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span className="material-symbols-outlined"></span> Help
                            </a>
                        </li>
                        <li className="divider"></li>
                        <li>
                            <a href="#">
                                <span className="material-symbols-outlined"></span> Logout
                            </a>
                        </li>
                    </ul>
                </details>
            </header>
            
            <div className="dashboard-body">
                <aside className="sidebar">
                    <div className="sidebar-header">
                        <h2>Write & Publish</h2>
                    </div>
                    <ul className="sidebar-menu">
                        {menuItems.map((item, index) => (
                            <li
                                key={index}
                                onClick={() => onSelect(item.component)}
                                className={`sidebar-item ${activeItem === item.component ? 'active' : ''}`}
                            >
                                <span className="sidebar-icon">{item.icon}</span>
                                {item.name}
                            </li>
                        ))}
                    </ul>
                </aside>
                
                <main className="main-content">
                    <h2>Books in Queue</h2>
                    <div className="book-button-container">
                    <div className="book-button-container">
      <button 
        className="book-creator-btn"
        onClick={handleCreateBook}
        aria-label="Create new book"
      >
        <div className="icon-container">
          <svg 
            className="plus-icon" 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 -960 960 960"
            aria-hidden="true"
          >
            <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z"/>
          </svg>
        </div>
        <span className="btn-text">Begin New Book</span>
        <div className="book-spine"></div>
        <div className="page-corner"></div>
        <div className="ink-splash"></div>
      </button>
    </div>
    </div>
                    <div className="book-grid">
                        <div className="book-card">
                            <img src="link-to-book-cover-1.jpg" alt="Eaters of the Dead" />
                            <h3>Eaters of the Dead</h3>
                            <p>Author: Michael Crichton</p>
                        </div>
                        <div className="book-card">
                            <img src="link-to-book-cover-2.jpg" alt="California" />
                            <h3>California</h3>
                            <p>Author: Edan Lepucki</p>
                        </div>
                        <div className="book-card">
                            <img src="link-to-book-cover-3.jpg" alt="A Clash of Kings" />
                            <h3>A Clash of Kings</h3>
                            <p>Author: George R.R. Martin</p>
                        </div>
                        <div className="book-card">
                            <img src="link-to-book-cover-4.jpg" alt="Jurassic Park" />
                            <h3>Jurassic Park</h3>
                            <p>Author: Michael Crichton</p>
                        </div>
                        <div className="book-card">
                            <img src="link-to-book-cover-5.jpg" alt="The Art of Racing in the Rain" />
                            <h3>The Art of Racing in the Rain</h3>
                            <p>Author: Garth Stein</p>
                        </div>
                        <div className="book-card">
                            <img src="link-to-book-cover-6.jpg" alt="The Hobbit" />
                            <h3>The Hobbit</h3>
                            <p>Author: J.R.R. Tolkien</p>
                        </div>
                    </div>
                </main>
                
            </div>
        </div>
    );
};

export default AuthorDashboard;