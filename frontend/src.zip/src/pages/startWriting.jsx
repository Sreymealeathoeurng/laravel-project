import React, { useState } from 'react';
import '../assets/styling/create.scss';
import { FaBook, FaImage, FaAlignLeft, FaTags, FaLanguage, FaCalendarAlt, FaSave } from 'react-icons/fa';

const startWriting = ({ onSave, onCancel }) => {
  const [bookData, setBookData] = useState({
    title: '',
    description: '',
    coverImage: '',
    genre: '',
    language: '',
    publicationDate: '',
    isbn: ''
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBookData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBookData(prev => ({
          ...prev,
          coverImage: reader.result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!bookData.title.trim()) newErrors.title = 'Title is required';
    if (!bookData.description.trim()) newErrors.description = 'Description is required';
    if (!bookData.genre.trim()) newErrors.genre = 'Genre is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      onSave(bookData);
    }
  };

  return (
    
    <div className="create-book-form">
      <div className="form-grid">
      <div className="form-header">
        <h2>Book Details</h2>
        <p>Fill in the details below to add a new book to your collection</p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="form-grid">
          <div className="form-column">
            <div className={`form-group ${errors.title ? 'error' : ''}`}>
              <label htmlFor="title">
                <FaBook className="input-icon" />
                Book Title
              </label>
              <input
                type="text"
                id="title"
                name="title"
                value={bookData.title}
                onChange={handleChange}
                placeholder="Enter book title"
              />
              {errors.title && <span className="error-message">{errors.title}</span>}
            </div>

            <div className={`form-group ${errors.description ? 'error' : ''}`}>
              <label htmlFor="description">
                <FaAlignLeft className="input-icon" />
                Description
              </label>
              <textarea
                id="description"
                name="description"
                value={bookData.description}
                onChange={handleChange}
                placeholder="Enter book description"
                rows="5"
              />
              {errors.description && <span className="error-message">{errors.description}</span>}
            </div>

            <div className={`form-group ${errors.genre ? 'error' : ''}`}>
              <label htmlFor="genre">
                <FaTags className="input-icon" />
                Genre
              </label>
              <select
                id="genre"
                name="genre"
                value={bookData.genre}
                onChange={handleChange}
              >
                <option value="">Select a genre</option>
                <option value="Fiction">Fiction</option>
                <option value="Non-Fiction">Non-Fiction</option>
                <option value="Science Fiction">Science Fiction</option>
                <option value="Fantasy">Fantasy</option>
                <option value="Mystery">Mystery</option>
                <option value="Romance">Romance</option>
                <option value="Thriller">Thriller</option>
                <option value="Biography">Biography</option>
              </select>
              {errors.genre && <span className="error-message">{errors.genre}</span>}
            </div>
          </div>

          {/* Right Column */}
          <div className="form-column">
            <div className="form-group">
              <label htmlFor="coverImage">
                <FaImage className="input-icon" />
                Cover Image
              </label>
              <div className="image-upload">
                {bookData.coverImage ? (
                  <div className="image-preview">
                    <img src={bookData.coverImage} alt="Book cover preview" />
                    <button 
                      type="button" 
                      className="change-image-btn"
                      onClick={() => document.getElementById('coverImage').click()}
                    >
                      Change Image
                    </button>
                  </div>
                ) : (
                  <div 
                    className="upload-placeholder"
                    onClick={() => document.getElementById('coverImage').click()}
                  >
                    <FaImage size={40} />
                    <span>Click to upload cover image</span>
                  </div>
                )}
                <input
                  type="file"
                  id="coverImage"
                  name="coverImage"
                  accept="image/*"
                  onChange={handleImageUpload}
                  style={{ display: 'none' }}
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="language">
                <FaLanguage className="input-icon" />
                Language
              </label>
              <select
                id="language"
                name="language"
                value={bookData.language}
                onChange={handleChange}
              >
                <option value="">Select language</option>
                <option value="English">English</option>
                <option value="Spanish">Khmer</option>
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="publicationDate">
                <FaCalendarAlt className="input-icon" />
                Publication Date
              </label>
              <input
                type="date"
                id="publicationDate"
                name="publicationDate"
                value={bookData.publicationDate}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label htmlFor="isbn">ISBN</label>
              <input
                type="text"
                id="isbn"
                name="isbn"
                value={bookData.isbn}
                onChange={handleChange}
                placeholder="Enter ISBN number"
              />
            </div>
          </div>
        </div>

        <div className="form-actions">
          <button type="button" className="cancel-btn" onClick={onCancel}>
            Cancel
          </button>
          <button type="submit" className="save-btn">
            <FaSave className="btn-icon" />
            Save Book
          </button>
        </div>
      </form>
      </div>
   
    </div>
  );
};


    export default startWriting;