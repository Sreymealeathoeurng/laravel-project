import React, { useState } from 'react';
import '../assets/styling/genres.scss';
import Header from './header'; 
import MyBook from './MyBook';
import MyLibrary from './MyLibrary';
import Footer from './Footer';

import bm from '../assets/images/bookING.png';
import gr from '../assets/images/genres.png';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

const Genres = () => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const [activeTab, setActiveTab] = useState('Genres');
    

    const books = [
        { title: 'The Wheel of Time', author: 'Robert Jordan', image: '../assets/images/bookING.jpg' },
        { title: 'Rich Dad Poor Dad', author: 'Robert T. Kiyosaki', image: '../assets/images/book2.jpg' },
        { title: 'Game of Thrones', author: 'George R. R. Martin', image: '../assets/images/book3.jpg' },
        { title: "I Don't Love You Anymore", author: 'Rithvik Singh', image: '../assets/images/book4.jpg' },
        { title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', image: '../assets/images/book5.jpg' },
        { title: '1984', author: 'George Orwell', image: '../assets/images/book6.jpg' },
        { title: 'To Kill a Mockingbird', author: 'Harper Lee', image: '../assets/images/book7.jpg' },
        { title: 'The Catcher in the Rye', author: 'J.D. Salinger', image: '../assets/images/book8.jpg' },
    ];

    const nextCards = () => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % Math.ceil(books.length / 5));
    };

    const prevCards = () => {
        setCurrentIndex((prevIndex) => (prevIndex - 1 + Math.ceil(books.length / 5)) % Math.ceil(books.length / 5));
    };

    const startIndex = currentIndex * 5;
    const currentBooks = books.slice(startIndex, startIndex + 5);

    const handleTabChange = (newTab) => {
        setActiveTab(newTab);
    };

    return (
        <><div className="genres">
            <Header activeTab={activeTab} onTabChange={handleTabChange} />

            {activeTab === 'MyBook' && <MyBook />}
            {activeTab === 'MyLibrary' && <MyLibrary />}

            {activeTab !== 'MyBook' && activeTab !== 'MyLibrary' && (
                <>
                    <nav className="genres-menu">
                        <div className="bg-light">
                            <ul>
                                {['Fiction', 'Non-Fiction', 'Mystery', 'Science Fiction', 'Fantasy', 'Biography', 'History', 'Self-Help'].map((genre) => (
                                    <li key={genre}>
                                        <a href="#" onClick={() => handleTabChange(genre)}>{genre}</a>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </nav>

                    <div className="col-md">
                        <div className="row1">
                            <div className="col-md-8">
                                <section className="image-card">
                                    <img src={gr} alt="Genres Illustration" />
                                    <div className="bs5-grid-row">
                                        <span id="welcome-text">
                                            Welcome to the World of <span id="fiction-text">Fiction</span>
                                        </span>
                                        <p>
                                            Explore thrilling adventures, heartwarming romances, and mind-bending mysteries.
                                            Dive into new worlds, unforgettable characters, and captivating plots.
                                        </p>
                                        <p>
                                            Fantasy & Sci-Fi<br />
                                            Mystery & Thriller<br />
                                            Romance<br />
                                            Historical Fiction<br />
                                            Short Stories<br />
                                            Your next great read awaits. Start the adventure now!
                                        </p>
                                    </div>
                                </section>
                            </div>
                            <section className='st-title'>
                                <h2>New Releases</h2>
                            </section>
                            <div className="new-releases">
                                <div className="slider-container">
                                    <button onClick={prevCards} className="nav-button">❮</button>
                                    <div className="card-container">
                                        {currentBooks.map((book, index) => (
                                            <div className="card" key={index}>
                                                <img src={book.image} className="card-image" alt={`Cover of ${book.title}`} />
                                                <h3>{book.title}</h3>
                                                <p>{book.author}</p>
                                                <button className="action-button">{index % 2 === 0 ? 'Borrow' : 'Not in Library'}</button>
                                            </div>
                                        ))}
                                    </div>
                                    <button onClick={nextCards} className="nav-button">❯</button>
                                </div>
                            </div>
                            <section className='st-title'>
                                <h2>New Releases</h2>
                            </section>
                            <div className="new-releases">
                                <div className="slider-container">
                                    <button onClick={prevCards} className="nav-button">❮</button>
                                    <div className="card-container">
                                        {currentBooks.map((book, index) => (
                                            <div className="card" key={index}>
                                                <img src={book.image} className="card-image" alt={`Cover of ${book.title}`} />
                                                <h3>{book.title}</h3>
                                                <p>{book.author}</p>
                                                <button className="action-button">{index % 2 === 0 ? 'Borrow' : 'Not in Library'}</button>
                                            </div>
                                        ))}
                                    </div>
                                    <button onClick={nextCards} className="nav-button">❯</button>
                                </div>
                            </div>
                            <div className="all-book">
                                <div className="slider-container">
                                    <button onClick={prevCards} className="nav-button">❮</button>
                                    <div className="card-container">
                                        {currentBooks.map((book, index) => (
                                            <div className="card" key={index}>
                                                <img src={book.image} className="card-image" alt={`Cover of ${book.title}`} />
                                                <h3>{book.title}</h3>
                                                <p>{book.author}</p>
                                                <button className="action-button">{index % 2 === 0 ? 'Borrow' : 'Not in Library'}</button>
                                            </div>
                                        ))}
                                    </div>
                                    <button onClick={nextCards} className="nav-button">❯</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </>
            )}

        </div><Footer /></>
    );
};

export default Genres;