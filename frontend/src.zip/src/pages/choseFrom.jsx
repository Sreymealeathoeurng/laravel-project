import React, { useState } from 'react';
import { FaBookReader, FaPenFancy } from 'react-icons/fa';
import '../assets/styling/create.scss'; // Styles provided below

const choseFrom = ({ onRoleSelect }) => {
  const [selectedRole, setSelectedRole] = useState(null);

  const handleRoleSelect = (role) => {
    setSelectedRole(role);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedRole) {
      onRoleSelect(selectedRole);
    }
  };

  return (
    <div className="role-selection-container">
      <h2>Welcome to StoryCraft</h2>
      <p className="subtitle">Are you here to read or create?</p>
      
      <form onSubmit={handleSubmit}>
        <div className="role-options">
          <div 
            className={`role-card ${selectedRole === 'reader' ? 'selected' : ''}`}
            onClick={() => handleRoleSelect('reader')}
          >
            <div className="role-icon reader">
              <FaBookReader size={48} />
            </div>
            <h3>Reader</h3>
            <p>Discover amazing stories, join discussions, and track your reading journey.</p>
          </div>

          <div 
            className={`role-card ${selectedRole === 'author' ? 'selected' : ''}`}
            onClick={() => handleRoleSelect('author')}
          >
            <div className="role-icon author">
              <FaPenFancy size={48} />
            </div>
            <h3>Author</h3>
            <p>Write and publish your stories, engage with readers, and view analytics.</p>
          </div>
        </div>

        <button 
          type="submit" 
          className="continue-button"
          disabled={!selectedRole}
        >
          Continue as {selectedRole || '...'}
        </button>
      </form>
    </div>
  );
};

export default choseFrom;