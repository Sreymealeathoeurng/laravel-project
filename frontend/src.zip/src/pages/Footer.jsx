import React from 'react';
import '../assets/styling/Footer.scss';
import { 
  FaHeart, 
  FaComment, 
  FaShareAlt, 
  FaBookmark, 
  FaUserFriends,
  FaTrophy,
  FaRegLightbulb
} from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="reader-engagement-footer">
      {/* Quick Engagement Bar (Fixed on mobile) */}
      <div className="quick-engagement-bar">
        <button className="engagement-btn" aria-label="Like this chapter">
          <FaHeart className="icon" />
          <span className="count">142</span>
        </button>
        
        <button className="engagement-btn" aria-label="View comments">
          <FaComment className="icon" />
          <span className="count">23</span>
        </button>
        
        <button className="engagement-btn" aria-label="Bookmark">
          <FaBookmark className="icon" />
        </button>
        
        <button className="engagement-btn" aria-label="Share">
          <FaShareAlt className="icon" />
        </button>
      </div>

      {/* Main Footer Content */}
      <div className="footer-content">
        <div className="footer-section">
          <h3>Community</h3>
          <ul>
            <li><FaUserFriends /> Reading Groups</li>
            <li><FaTrophy /> Reading Challenges</li>
            <li><FaRegLightbulb /> Fan Contributions</li>
          </ul>
        </div>
        
        <div className="footer-section">
          <h3>Author Tools</h3>
          <ul>
            <li>Analytics Dashboard</li>
            <li>Reader Feedback</li>
            <li>Engagement Metrics</li>
          </ul>
        </div>
        
        <div className="footer-section">
          <h3>Reading Tools</h3>
          <ul>
            <li>Dark Mode</li>
            <li>Text Preferences</li>
            <li>Audio Narration</li>
          </ul>
        </div>
      </div>

      {/* Copyright */}
      <div className="copyright">
        © {new Date().getFullYear()} BookCraft | Reader Engagement Platform
      </div>
    </footer>
  );
};

export default Footer;