import React, { useEffect } from 'react';
import { Editor } from '@tinymce/tinymce-react';

const RichTextEditor = ({ initialValue, onChange, placeholder }) => {
  const handleEditorChange = (content) => {
    if (onChange) {
      onChange(content);
    }
  };

  return (
    <div className="rich-text-editor">
      <Editor
      
      apiKey='ryr9cxgw40nmvoua4oldb8ci9jsz9kts70dvi3377ydni73w'
      
        initialValue={initialValue}
        init={{
          height: 400,
          menubar: false,
          plugins: 'link image code',
          toolbar: 'undo redo | styles | bold italic | alignleft aligncenter alignright | code',
          placeholder: placeholder || "Start writing here..."
        }}
        onEditorChange={handleEditorChange}
      />
    </div>
  );
};

export default RichTextEditor;