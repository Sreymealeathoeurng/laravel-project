import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/home';
import Genres from './pages/Genres';
import AuthorDashboard from './pages/AuthorDashboard'; 
import RoleSelection from './pages/choseFrom';
import StartWriting from './pages/startWriting';


function App() {
  return (
    <Router>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/genres' element={<Genres />} />
        <Route path='/author-dashboard' element={<AuthorDashboard />} />
        <Route path='/role-selection' element={<RoleSelection />} />
        <Route path='/start-writing' element={<StartWriting />} />
      </Routes>
    </Router>
  );
}

export default App;